﻿// ==========================================================================================================
// background.js - Service Worker for in-page text search extension
// 페이지 내 텍스트 검색 확장 프로그램의 백그라운드 서비스 워커 스크립트.
// ==========================================================================================================

// ## 단계 100: 확장 프로그램 설치 및 초기 설정 초기화
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//----------------------------------------------------------------------------------------------------------
// Date 객체를 YYMMDD.HHmm 형식(예: 261003.1432)의 버전 문자열로 변환한다.
// 입력: date - Date 객체 (기본값: 현재 시각)
// 출력: "YYMMDD.HHmm" 형태의 포맷팅된 문자열
//----------------------------------------------------------------------------------------------------------
function formatPackageLoadTime(date = new Date()) {
    const yy = String(date.getFullYear()).slice(-2);
    const mm = String(date.getMonth() + 1).padStart(2, '0');
    const dd = String(date.getDate()).padStart(2, '0');
    const hh = String(date.getHours()).padStart(2, '0');
    const min = String(date.getMinutes()).padStart(2, '0');
    return `${yy}${mm}${dd}.${hh}${min}`;
}

// 서비스 워커 초기 로드 시 패키지 로드 시각 저장 상태 확인
chrome.storage.local.get(['packageLoadTime'], (res) => {
    if (!res || !res.packageLoadTime) {
        chrome.storage.local.set({ packageLoadTime: formatPackageLoadTime(new Date()) });
    }
});

chrome.runtime.onInstalled.addListener((details) => {
    // 설치 또는 업데이트 로그 기록
    console.log('Text Search Extension installed:', details.reason);

    // 로컬 패키지 로드 시각 기록 (마켓플레이스로부터의 업데이트가 아닌 경우 갱신)
    const manifest = chrome.runtime.getManifest ? chrome.runtime.getManifest() : {};
    const isFromStore = Boolean(manifest.update_url && manifest.update_url.includes('google.com'));
    if (!isFromStore) {
        chrome.storage.local.set({ packageLoadTime: formatPackageLoadTime(new Date()) });
    }

    // 스토리지에 기본 설정값이 없을 경우 기본값으로 초기화
    chrome.storage.sync.get([
        'shortcut',
        'autoMove',
        'showDashboard',
        'highlightColor',
        'activeHighlightColor',
        'defaultBarCount',
        'lastBarsState',
        'ignoreDelimiters'
    ], (result) => {
        const defaults = {};

        // 기본 단축키: Ctrl + F
        if (!result.shortcut) {
            defaults.shortcut = { ctrl: true, alt: false, shift: false, meta: false, key: 'f' };
        }
        // 첫 번째 일치 항목 자동 스크롤 이동 기본값: true
        if (typeof result.autoMove !== 'boolean') {
            defaults.autoMove = true;
        }
        if (typeof result.showDashboard !== 'boolean') {
            defaults.showDashboard = false;
        }
        // 기본 일치 하이라이트 색상: 노란색
        if (!result.highlightColor) {
            defaults.highlightColor = '#ffe600';
        }
        // 활성 일치 하이라이트 색상: 주황색
        if (!result.activeHighlightColor) {
            defaults.activeHighlightColor = '#ff8f00';
        }
        // 기본 검색바 개수 초기값: 2개
        if (typeof result.defaultBarCount !== 'number') {
            defaults.defaultBarCount = 2;
        }
        // 선택기능 단어 확장 시 무시할 구분자 기본값: '-'
        if (typeof result.ignoreDelimiters !== 'string') {
            defaults.ignoreDelimiters = '-';
        }

        // 미설정 항목이 있는 경우 스토리지에 일괄 저장
        if (Object.keys(defaults).length > 0) {
            chrome.storage.sync.set(defaults);
        }
    });
});
